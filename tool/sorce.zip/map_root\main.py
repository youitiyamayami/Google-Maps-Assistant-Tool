import os
import threading
import queue
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

# 追加：カレンダー（日付ピッカー）
from tkcalendar import DateEntry

# ローカルモジュール
from modules.config_loader import load_config          # 設定ロード関数
from modules.app_logger import get_app_logger          # アプリ用ロガー取得関数
from modules.gmaps_url_builder import build_gmaps_url  # GoogleマップURL生成
from modules.maps_driver import MapsDriver             # ブラウザ操作ドライバ
from modules.route_parser import parse_route_from_page # ルート詳細テキストの解析
from modules.formatter import format_route_text        # 出力テキストの整形

# --------------------------------------------------------------------------------------
# アプリ定数
# --------------------------------------------------------------------------------------
APP_TITLE = "Googleマップ 中継地点ありルート抽出 (MVP/GUI)"  # ウィンドウタイトル
OUTPUT_ROOT = "output"                                        # 出力ルートディレクトリ

# 中継地点入力を「一時的に」無効化するフラグ
# True : GUIの中継地エントリを編集不可にし、実行時も中継地は常に未使用（=空）で処理
# False: 従来どおり中継地を利用（GUIで入力→検索に反映）
VIA_DISABLED = True


class App(tk.Tk):
    """
    GUIアプリ本体クラス。
    - 画面構築、イベント処理（実行/停止）、ログ表示、バックグラウンド処理を担当。
    - 中継地点の入力フィールドは VIA_DISABLED に従って有効/無効を切り替える。
    """

    def __init__(self):
        """
        アプリ起動時の初期化処理。
        - ウィンドウ設定、設定/ロガーの準備、ログキュー、UI構築、ワーカ制御の準備を行う。
        """
        super().__init__()
        self.title(APP_TITLE)
        # 高さ少し拡張（時刻入力UI分）
        self.geometry("780x640")

        # self.cfg: dict … modules/config_loader.py の load_config() が返すアプリ設定
        self.cfg = load_config()
        # self.lg : logging.Logger … modules/app_logger.py の get_app_logger() が返すロガー
        self.lg = get_app_logger()

        # self.msg_q: queue.Queue[str] … GUIスレッドとワーカースレッド間でログ文を受け渡し
        self.msg_q: "queue.Queue[str]" = queue.Queue()
        # 100msごとにキューを排出してテキストエリアへ反映
        self.after(100, self._drain_log_queue)

        # 画面部品の構築
        self._build_ui()

        # self.worker_thread: threading.Thread|None … バックグラウンド処理スレッド
        self.worker_thread: threading.Thread | None = None
        # self.stop_flag: threading.Event … 停止要求を伝達するイベントフラグ
        self.stop_flag = threading.Event()

    def _build_ui(self):
        """
        画面部品（ウィジェット）の構築。
        既存レイアウトを維持しつつ、中継地点エントリのみ state='disabled' とする（VIA_DISABLED=True の場合）。
        """
        pad = {"padx": 10, "pady": 6}  # 各部品の余白設定

        frm = ttk.Frame(self)          # ルートフレーム
        frm.pack(fill="both", expand=True)

        # --- 出発地 / 中継地 / 到着地 ---
        ttk.Label(frm, text="出発地").grid(row=0, column=0, sticky="w", **pad)
        # self.ent_from: ttk.Entry … 出発地入力エントリ
        self.ent_from: ttk.Entry = ttk.Entry(frm, width=50)
        self.ent_from.grid(row=0, column=1, columnspan=2, sticky="we", **pad)

        ttk.Label(frm, text="中継地（'|'区切り）").grid(row=1, column=0, sticky="w", **pad)
        # self.ent_via: ttk.Entry … 中継地入力エントリ（今回無効化の対象）
        self.ent_via: ttk.Entry = ttk.Entry(frm, width=50)
        self.ent_via.grid(row=1, column=1, columnspan=2, sticky="we", **pad)
        if VIA_DISABLED:
            # 無効化（編集できない状態）。レイアウトは既存のまま維持。
            self.ent_via.configure(state="disabled")

        ttk.Label(frm, text="到着地").grid(row=2, column=0, sticky="w", **pad)
        # self.ent_to: ttk.Entry … 到着地入力エントリ
        self.ent_to: ttk.Entry = ttk.Entry(frm, width=50)
        self.ent_to.grid(row=2, column=1, columnspan=2, sticky="we", **pad)

        # --- 出発時刻（任意）：チェック＋カレンダー＋プルダウン ---
        # self.var_use_depart: tk.BooleanVar … 出発時刻を指定するかどうか
        self.var_use_depart: tk.BooleanVar = tk.BooleanVar(value=False)
        # self.chk_use_depart: ttk.Checkbutton … 出発時刻指定のON/OFF
        self.chk_use_depart: ttk.Checkbutton = ttk.Checkbutton(
            frm,
            text="出発時刻を指定する",
            variable=self.var_use_depart,
            command=self._toggle_depart_widgets
        )
        self.chk_use_depart.grid(row=3, column=0, sticky="w", **pad)

        ttk.Label(frm, text="日付").grid(row=4, column=0, sticky="w", **pad)
        today = datetime.now()
        # self.cal_date: DateEntry … tkcalendar の日付入力（yyyy-mm-dd）
        self.cal_date: DateEntry = DateEntry(
            frm,
            width=12,
            date_pattern="yyyy-mm-dd",  # 文字列化の一貫性を担保
            year=today.year, month=today.month, day=today.day
        )
        self.cal_date.grid(row=4, column=1, sticky="w", **pad)

        ttk.Label(frm, text="時刻").grid(row=4, column=2, sticky="w", **pad)
        hours = [f"{h:02d}" for h in range(24)]          # 0..23 の2桁文字列
        minutes = [f"{m:02d}" for m in range(0, 60, 5)]  # 0..55 の5分刻み2桁文字列

        # self.cmb_hour: ttk.Combobox … 時のプルダウン（readonly）
        self.cmb_hour: ttk.Combobox = ttk.Combobox(frm, values=hours, width=5, state="readonly")
        # self.cmb_min : ttk.Combobox … 分のプルダウン（readonly）
        self.cmb_min: ttk.Combobox = ttk.Combobox(frm, values=minutes, width=5, state="readonly")

        # デフォルトは現在時刻（5分刻みに丸め）
        now = datetime.now()
        default_hour = f"{now.hour:02d}"
        default_min = f"{(now.minute // 5) * 5:02d}"
        self.cmb_hour.set(default_hour)
        self.cmb_min.set(default_min)

        # 既存レイアウト踏襲（位置は変更しない）
        self.cmb_hour.grid(row=4, column=2, sticky="e", padx=(0, 72), pady=6)
        self.cmb_min.grid(row=4, column=2, sticky="e", padx=(0, 10), pady=6)

        # 初期状態は無効（チェックONで有効化）
        self._set_depart_widgets_state(enabled=False)

        # --- 可変式（駅間の移動時間の感覚：小/中/大） ---
        ttk.Label(frm, text="移動時間の感覚").grid(row=5, column=0, sticky="w", **pad)
        # self.cmb_bucket: ttk.Combobox … 「小/中/大」バケット（見やすさ調整パラメータ）
        self.cmb_bucket: ttk.Combobox = ttk.Combobox(frm, values=["小", "中", "大"], state="readonly", width=10)
        self.cmb_bucket.current(1)  # デフォルト: 中
        self.cmb_bucket.grid(row=5, column=1, sticky="w", **pad)

        # --- 実行 / 停止ボタン ---
        # self.btn_run : ttk.Button … 実行ボタン
        self.btn_run: ttk.Button = ttk.Button(frm, text="実行", command=self.on_run)
        self.btn_run.grid(row=6, column=1, sticky="e", **pad)
        # self.btn_stop: ttk.Button … 停止ボタン（処理中のみ有効）
        self.btn_stop: ttk.Button = ttk.Button(frm, text="停止", command=self.on_stop, state="disabled")
        self.btn_stop.grid(row=6, column=2, sticky="w", **pad)

        # --- ログ表示 ---
        ttk.Label(frm, text="ログ").grid(row=7, column=0, sticky="w", **pad)
        # self.txt_log: tk.Text … ログ表示用テキストエリア
        self.txt_log: tk.Text = tk.Text(frm, height=16)
        self.txt_log.grid(row=8, column=0, columnspan=3, sticky="nsew", **pad)

        # リサイズ時の拡張設定
        frm.rowconfigure(8, weight=1)
        frm.columnconfigure(1, weight=1)
        frm.columnconfigure(2, weight=1)

    def _set_depart_widgets_state(self, enabled: bool):
        """
        出発時刻関連ウィジェット（カレンダー、時・分）の有効/無効を切り替える。
        Parameters
        ----------
        enabled : bool
            True で有効化、False で無効化。
        """
        state = "normal" if enabled else "disabled"
        for w in (self.cal_date, self.cmb_hour, self.cmb_min):
            try:
                w.config(state=state)
            except Exception:
                # ttkの状態設定で例外が出てもアプリを止めない（安全側）
                pass

    def _toggle_depart_widgets(self):
        """
        チェックボックス操作時に、出発時刻関連ウィジェットの状態を更新する。
        """
        self._set_depart_widgets_state(self.var_use_depart.get())

    def log(self, msg: str):
        """
        GUIテキストとアプリロガーの双方にログを出力する。
        Parameters
        ----------
        msg : str
            出力するメッセージ（タイムスタンプはここで付与）。
        """
        ts = datetime.now().strftime("%Y:%m:%d %H:%M:%S")
        line = f"[{ts}] {msg}"
        # GUI側へはキュー経由で渡す（スレッドセーフ）
        self.msg_q.put(line)
        # ファイル/コンソール等へはロガーで
        self.lg.info(msg)

    def _drain_log_queue(self):
        """
        キューに貯まっているログメッセージをテキストエリアへ流し込む。
        100ms周期で自動実行。GUIスレッドで動作する。
        """
        try:
            while True:
                line = self.msg_q.get_nowait()
                self.txt_log.insert("end", line + "\n")
                self.txt_log.see("end")
        except queue.Empty:
            pass
        # 次回実行の予約
        self.after(100, self._drain_log_queue)

    def on_run(self):
        """
        実行ボタン押下時の処理。
        - 入力検証
        - 出発時刻パラメータの構築
        - 出力ディレクトリの準備
        - ワーカースレッドの起動
        """
        # 二重起動防止
        if self.worker_thread and self.worker_thread.is_alive():
            messagebox.showwarning("実行中", "処理がまだ実行中です。")
            return

        origin = self.ent_from.get().strip()  # 出発地
        # 中継地は今回無効化しているため取得はするが使用しない（VIA_DISABLED=True のとき）
        via_raw = "" if VIA_DISABLED else self.ent_via.get().strip()
        dest = self.ent_to.get().strip()      # 到着地
        bucket = self.cmb_bucket.get()        # 「小/中/大」

        # 必須チェック
        if not origin or not dest:
            messagebox.showerror("入力不足", "出発地と到着地は必須です。")
            return

        # 中継地の扱い：無効化中は常に空リストに固定
        if VIA_DISABLED:
            waypoints: list[str] = []
            self.log("中継地点は一時的に無効化されています（waypoints は空で実行）。")
        else:
            waypoints = [v.strip() for v in via_raw.split("|") if v.strip()] if via_raw else []

        language = self.cfg["app"]["language"]  # Googleマップの言語（例: "ja"）
        region = self.cfg["app"]["region"]      # 地域コード（例: "JP"）

        # 出発時刻（チェックONなら "YYYY-MM-DD HH:MM" を組み立て）
        if self.var_use_depart.get():
            date_str = self.cal_date.get_date().strftime("%Y-%m-%d")
            hour_str = self.cmb_hour.get()
            min_str = self.cmb_min.get()
            depart_at = f"{date_str} {hour_str}:{min_str}"
        else:
            depart_at = None  # 未指定→Google側の "now"

        # 出力先ディレクトリ/ファイル
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        outdir = os.path.join(OUTPUT_ROOT, stamp)
        os.makedirs(outdir, exist_ok=True)
        outfile_txt = os.path.join(outdir, "route.txt")

        # ワーカー起動準備
        self.stop_flag.clear()
        self.btn_run.config(state="disabled")
        self.btn_stop.config(state="normal")

        # ワーカースレッドへ渡す引数をまとめる
        args = (origin, waypoints, dest, depart_at, language, region, bucket, outfile_txt)
        self.worker_thread = threading.Thread(target=self._worker, args=args, daemon=True)
        self.worker_thread.start()

    def on_stop(self):
        """
        停止ボタン押下時の処理。
        - 停止フラグを立て、ワーカースレッドが安全に停止できるようにする。
        """
        if self.worker_thread and self.worker_thread.is_alive():
            self.stop_flag.set()
            self.log("停止要求を送信しました（処理の安全停止を待機）。")

    def _worker(self,
                origin: str,
                waypoints: list[str],
                dest: str,
                depart_at: str | None,
                language: str,
                region: str,
                bucket: str,
                outfile_txt: str):
        """
        バックグラウンドで実行する本処理。
        - GoogleマップのURL生成
        - ブラウザ起動と遷移、詳細表示の開閉、ページテキスト抽出
        - 抽出テキストの解析とフォーマット
        - テキスト出力の保存
        Parameters
        ----------
        origin : str
            出発地
        waypoints : list[str]
            中継地点リスト（今回の版では空想定）
        dest : str
            到着地
        depart_at : str | None
            出発日時（"YYYY-MM-DD HH:MM" 形式）/ None なら「今すぐ」
        language : str
            Googleマップの言語コード
        region : str
            Googleマップの地域コード
        bucket : str
            「小/中/大」の見やすさ調整パラメータ
        outfile_txt : str
            出力するテキストファイルのパス
        """
        try:
            self.log("URL生成中…")
            url = build_gmaps_url(
                origin=origin,
                destination=dest,
                waypoints=waypoints,    # 無効化中は常に []
                mode="transit",
                language=language,
                region=region,
                depart_at=depart_at,    # None なら "now"
            )
            self.log(f"URL: {url}")

            self.log("ブラウザ起動中…")
            drv = MapsDriver(self.cfg)
            try:
                self.log("ページへ遷移中…")
                drv.open(url)

                if self.stop_flag.is_set():
                    return

                self.log("「詳細」を開いています…")
                drv.open_details_panel()

                if self.stop_flag.is_set():
                    return

                self.log("ページからテキスト抽出中…")
                page_text = drv.get_details_text_fallback()

            finally:
                drv.close()

            if self.stop_flag.is_set():
                return

            self.log("抽出テキストを解析中…")
            route = parse_route_from_page(
                page_text=page_text,
                origin=origin,
                destination=dest,
                waypoints=waypoints,  # [] 想定
                language=language,
            )

            self.log("見やすいテキストに整形中…")
            txt = format_route_text(
                route=route,
                bucket_level=bucket,  # 「小/中/大」
                cfg=self.cfg,
            )

            with open(outfile_txt, "w", encoding=self.cfg["app"]["encoding"]) as f:
                f.write(txt)

            self.log(f"保存しました: {outfile_txt}")
            # （注意）Tkのスレッド安全性の観点では、messageboxはGUIスレッドで呼ぶのが安全です
            # MVPのままにしていますが、問題が出る場合は after() でGUIスレッド実行に切り替えてください。
            messagebox.showinfo("完了", f"保存しました:\n{outfile_txt}")

        except Exception as e:
            self.lg.exception("実行中にエラー")
            messagebox.showerror("エラー", f"実行中にエラーが発生しました:\n{e}")
        finally:
            self.btn_run.config(state="normal")
            self.btn_stop.config(state="disabled")


if __name__ == "__main__":
    # アプリ起動
    app = App()
    app.mainloop()
